# Randos (Derk Gym Agent)

Agent for [Derk's Gym](https://gym.derkgame.com) that just behave randomly. Dockerized for easy deployment.

To run a server with docker:
```
docker pull mountrouke/randos
docker run -t mountrouke/randos
```

To run a server locally:
1. Clone this repo
2. pip install -r requirements.txt
3. `python derk_randos.py --server`
